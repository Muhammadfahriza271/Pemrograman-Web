<?php
class Mahasiswa extends CI_Controller{
    // Membuat method index 
    public function index(){
        // $this->load->model('mahasiswa_model', 'mhs1');

        // // Buat object model 1 dan nilai nya
        // $this->mhs1->id=1;
        // $this->mhs1->nim='0111';
        // $this->mhs1->nama='Fahriza';
        // $this->mhs1->gender='L';
        // $this->mhs1->ipk=3.95;

        // $this->load->model('mahasiswa_model','mhs2');

        // // Buat object model 2 dan nilai nya
        // $this->mhs2->id=2;
        // $this->mhs2->nim='0112';
        // $this->mhs2->nama='Fahira';
        // $this->mhs2->gender='P';
        // $this->mhs2->ipk=3.55;

        // Simpan object yang kita buat kedalam array
        // $list_mhs = [$this->mhs1, $this->mhs2];
        // Siapkan data untuk dikirim ke dalam views, dimana data diambil dari object yang kita simpan kedalam array 
        // $data['list_mhs'] = $list_mhs;


        // Akses model mahasiswa
        $this->load->model('mahasiswa_model');
        $mahasiswa = $this->mahasiswa_model->getAll();
        $data['mahasiswa'] = $mahasiswa;

        // Render data dan kirim kedalam view
        $this->load->view('layouts/header');
        $this->load->view('mahasiswa/index', $data);
        $this->load->view('layouts/footer');
    }
        public function detail($id){
        // akses model mahasiswa
        $this->load->model('mahasiswa_model');
        $siswa = $this->mahasiswa_model-> getById($id);
        $data['siswa'] = $siswa;
        $this->load->view('layouts/header');
        $this->load->view('mahasiswa/detail', $data);
        $this->load->view('layouts/footer');
    }
}
?>