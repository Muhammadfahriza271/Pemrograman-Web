<?php
class Dosen_model extends CI_Model{
    // Buat Property atau variable
    public $id, $nidn, $pendidikan;
}
?>