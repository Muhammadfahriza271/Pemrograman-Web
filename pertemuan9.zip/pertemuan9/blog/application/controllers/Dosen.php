<?php
class Dosen extends CI_Controller{
    // Membuat method index 
    public function index(){
        // $this->load->model('dosen_model', 'dsn1');

        // // Buat object model 1 dan nilai nya
        // $this->dsn1->id=1;
        // $this->dsn1->nidn='0222';
        // $this->dsn1->pendidikan='S2 Teknik Komputer';
        
        // $this->load->model('dosen_model', 'dsn2');

        // // Buat object model 2 dan nilai nya
        // $this->dsn2->id=2;
        // $this->dsn2->nidn='0223';
        // $this->dsn2->pendidikan='S2 Sistem Informasi';

        // $this->load->model('dosen_model', 'dsn3');

        // // Buat object model 3 dan nilai nya
        // $this->dsn3->id=3;
        // $this->dsn3->nidn='0224';
        // $this->dsn3->pendidikan='S2 Matematika';

        // Simpan object yang kita buat kedalam array
        // $list_dsn = [$this->dsn1, $this->dsn2, $this->dsn3];
        // Siapkan data untuk dikirim ke dalam views, dimana data diambil dari object yang kita simpan kedalam array 
        // $data['list_dsn'] = $list_dsn;

        // Akses model mahasiswa
        $this->load->model('dosen_model');
        $dosen = $this->dosen_model->getAll();
        $data['dosen'] = $dosen;

        // Render data dan kirim kedalam view
        $this->load->view('layouts/header');
        $this->load->view('dosen/index', $data);
        $this->load->view('layouts/footer');
    }
        public function detail($id){
        // akses model mahasiswa
        $this->load->model('dosen_model');
        $dosen = $this->dosen_model-> getById($id);
        $data['dosen'] = $dosen;
        $this->load->view('layouts/header');
        $this->load->view('dosen/detail', $data);
        $this->load->view('layouts/footer');
    }
    public function form(){
        // render view
        $this->load->view('layouts/header');
        $this->load->view('dosen/form');
        $this->load->view('layouts/footer');
    }
    public function save(){
        $this->load->model('dosen_model', 'dosen');
        $_nama = $this->input->post('nama');
        $_gender = $this->input->post('gender');
        $_tmp_lahir = $this->input->post('tmp_lahir');
        $_tgl_lahir = $this->input->post('tgl_lahir');
        $_nidn = $this->input->post('nidn');
        $_pendidikan = $this->input->post('pendidikan');

      
        $data_dosen['nama']=$_nama; //?2
        $data_dosen['gender']=$_gender;
        $data_dosen['tmp_lahir']=$_tmp_lahir;
        $data_dosen['tgl_lahir']=$_tgl_lahir;
        $data_dosen['nidn']=$_nidn;
        $data_dosen['pendidikan']=$_pendidikan;

        if (!empty($_idedit)) {// update
            $data_dosen['id']=$_idedit;//?3
            $this->dosen->update($data_dosen);
        } else {//data baru
            $this->dosen->simpan($data_dosen);
        }
        redirect('dosen', 'refresh');
    }
    public function edit($id){
        $this->load->model('dosen_model', 'dosen');
        $obj_dosen = $this->dosen->getById($id);
        $data['obj_dosen']=$obj_dosen;
            // render view
            $this->load->view('layouts/header');
            $this->load->view('dosen/edit', $data);
            $this->load->view('layouts/footer');    
    }

    public function delete($id){
        $this->load->model('dosen_model', 'dosen');
        // mengecek data dosen berdasarkan id
        $data_dosen['id']=$id;
        $this->dosen->delete($data_dosen);
        redirect('dosen', 'refresh');
    }
}
?> 