<?php
class Tampil_Matakuliah extends CI_Controller
{
    public function index(){

        // Akses model dosen
        $this->load->model('matakuliah_model');
        $matakuliah = $this->matakuliah_model->getAll();
        $data['matakuliah'] = $matakuliah;

        // Render data dan kirim kedalam view
        $this->load->view('layouts/header');
        $this->load->view('matakuliah/tampil', $data);
        $this->load->view('layouts/footer');
   }
}
?>