<?php
class Tampil_Dosen extends CI_Controller
{
    public function index()
    {
        // Akses model dosen
        $this->load->model('dosen_model');
        $dosen = $this->dosen_model->getAll();
        $data['dosen'] = $dosen;

        // Render data dan kirim kedalam view
        $this->load->view('layouts/header');
        $this->load->view('dosen/tampil', $data);
        $this->load->view('layouts/footer');
    }
}
?>