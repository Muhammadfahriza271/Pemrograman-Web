<?php
class Matakuliah_model extends CI_Model{
    // Buat Property atau variable
    public $id, $nama, $sks, $kode;

    public function getAll(){
        // Menampilkan seluruh data yang di table matakuliah menggunakan query builder\
        $query = $this->db->get('matakuliah');
        return $query->result();
    }
    public function getById($id){
        // menampilkan data berdasarkan id
        $query = $this->db->get_where('matakuliah', ['id' => $id]);
        return $query->row();
    }
    public function simpan($data){
        // insert auto bertujuan untuk mengingat atau memasukan data yang kita kirim ke dalam databse
        $sql = "INSERT INTO matakuliah (nama,sks,kode) VALUES (?,?,?)";

        $this->db->query($sql, $data);

        $insert_id = $this->db->insert_id();
        return $this->getById($insert_id);
    }
    public function update($data){
        // update table
        $sql = "UPDATE matakuliah SET nama=?,sks=?,kode=? WHERE id=?";
        $this->db->query($sql, $data);
    }
    public function delete($data){
        // delete table
        $sql = "DELETE FROM matakuliah WHERE id=?";
        $this->db->query($sql, $data);
    }
}
?> 