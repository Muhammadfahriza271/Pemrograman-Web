<?php
class Mahasiswa extends CI_Controller{
    // Membuat method index 
    public function index(){
        $this->load->model('mahasiswa_model', 'mhs1');

        // Buat object model 1 dan nilai nya
        $this->mhs1->id=1;
        $this->mhs1->nim='0111';
        $this->mhs1->nama='Fahriza';
        $this->mhs1->gender='L';
        $this->mhs1->ipk=3.95;

        $this->load->model('mahasiswa_model','mhs2');

        // Buat object model 2 dan nilai nya
        $this->mhs2->id=2;
        $this->mhs2->nim='0112';
        $this->mhs2->nama='Fahira';
        $this->mhs2->gender='P';
        $this->mhs2->ipk=3.55;

        // Simpan object yang kita buat kedalam array
        $list_mhs = [$this->mhs1, $this->mhs2];
        // Siapkan data untuk dikirim ke dalam views, dimana data diambil dari object yang kita simpan kedalam array 
        $data['list_mhs'] = $list_mhs;
        // Render data dan kirim kedalam view
        $this->load->view('mahasiswa/index', $data);
    }
}
?>