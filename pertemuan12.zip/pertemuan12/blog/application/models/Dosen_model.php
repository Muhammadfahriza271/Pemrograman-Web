<?php
class Dosen_model extends CI_Model
{
    // Buat Property atau variable
    public $id;
    public $nama;
    public $gender;
    public $tmp_lahir;
    public $tgl_lahir;
    public $nidn;
    public $pendidikan;


    public function getAll()
    {
        // Menampilkan seluruh data yang di table mahasiswa menggunakan query builder
        $query = $this->db->get('dosen');
        return $query->result();
    }
    public function getById($id)
    {
        // menampilkan data berdasarkan id
        $query = $this->db->get_where('dosen', ['id' => $id]);
        return $query->row();
    }
    public function simpan($data){
        // insert auto bertujuan untuk mengingat atau memasukan data yang kita kirim ke dalam databse
        $sql = "INSERT INTO dosen (nama,gender,tmp_lahir,tgl_lahir,nidn,pendidikan) VALUES (?,?,?,?,?,?)";

        $this->db->query($sql, $data);

        $insert_id = $this->db->insert_id();
        return $this->getById($insert_id);
    }
    public function update($data){
        // update table
        $sql = "UPDATE dosen SET nama=?,gender=?,tmp_lahir=?,tgl_lahir=?,nidn=?,pendidikan=? WHERE id=?";
        $this->db->query($sql, $data);
    }
    public function delete($data){
        // delete table
        $sql = "DELETE FROM dosen WHERE id=?";
        $this->db->query($sql, $data);
    }
}
?>