<?php
class Matakuliah extends CI_Controller{
    // Membuat method index 
    public function index(){
        $this->load->model('matakuliah_model', 'mk1');

        // Buat object model 1 dan nilai nya
        $this->mk1->id=1;
        $this->mk1->nama='Pemrograman Web';
        $this->mk1->sks=3;
        $this->mk1->kode='TIPW01';
        
        $this->load->model('matakuliah_model', 'mk2');

        // Buat object model 2 dan nilai nya
        $this->mk2->id=2;
        $this->mk2->nama='User Interface & User Experience';
        $this->mk2->sks=3;
        $this->mk2->kode='SIUIUX02';

        $this->load->model('matakuliah_model', 'mk3');

        // Buat object model 3 dan nilai nya
        $this->mk3->id=3;
        $this->mk3->nama='Matematika';
        $this->mk3->sks=3;
        $this->mk3->kode='TISIMTK03';
        // Simpan object yang kita buat kedalam array
        $list_mk = [$this->mk1, $this->mk2, $this->mk3];
        // Siapkan data untuk dikirim ke dalam views, dimana data diambil dari object yang kita simpan kedalam array 
        $data['list_mk'] = $list_mk;
        // Render data dan kirim kedalam view
        $this->load->view('matakuliah/index', $data);
    }
}
?>